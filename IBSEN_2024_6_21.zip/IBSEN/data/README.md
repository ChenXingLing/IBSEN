## Script Settings
Here are the script settings used in our paper. The original drama script was written in Chinese by a professional writer, and we translated it into English and designed the act flow. You can find the original Chinese script in [`original_script_zh.docx`](original_script_zh.docx).

Specifically, this drama script is protected under a different license from the code files, the CC BY-NC-SA 4.0 license (see below).

## License

 <p xmlns:cc="http://creativecommons.org/ns#" xmlns:dct="http://purl.org/dc/terms/"><span property="dct:title">Hedda, or What Will Gabler's Daughter Do?</span> by <a rel="cc:attributionURL dct:creator" property="cc:attributionName" href="https://smd.sjtu.edu.cn/teacher/detail/id/189">Li-Min Lin</a> is licensed under <a href="https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1" target="_blank" rel="license noopener noreferrer" style="display:inline-block;">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1" alt=""><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/by.svg?ref=chooser-v1" alt=""><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/nc.svg?ref=chooser-v1" alt=""><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/sa.svg?ref=chooser-v1" alt=""></a></p> 

