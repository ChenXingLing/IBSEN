# If you use API services to access the LLM, you can set your API key here.
OPENAI_API_KEY = "sk-123-3zb8Ql6xHOvf8nnw7pfWT3BlbkFJU5u8GemrnGKlYYb2lmMJ"