import copy
import os

import guidance

from api_key import OPENAI_API_KEY
from server.actor import GenerativeActor
from server.stage import GenerativeStage, Player

from transformers import AutoTokenizer

API_KEY = OPENAI_API_KEY
os.environ["OPENAI_API_KEY"] = API_KEY

# LLM_NAME = "gpt-3.5-turbo-1106"
# llama_path="your_path/llama-7b"
llama_path="./OpenLLaMa3B"

SCRIPT_PATH = "data/script/hedda_gabler_modern.json"

# guidance.llm = guidance.llms.OpenAI(LLM_NAME, chat_mode=True)
guidance.llm = guidance.llms.transformers.LLaMAChat(llama_path,device_map="auto")

# print("【!!!!!!!!】self.pad_token={}, self.pad_token_id={}, padding_strategy={}, PaddingStrategy.DO_NOT_PAD={}".format(self.pad_token, self.pad_token_id, padding_strategy, PaddingStrategy.DO_NOT_PAD))

# print("【guidance.llm.model_obj】",guidance.llm.model_obj)
# print("【guidance.llm.model_obj.config】",guidance.llm.model_obj.config)
# print("【guidance.llm.tokenizer】",guidance.llm.tokenizer)
# print("【guidance.llm.tokenizer.pad_token_id】",guidance.llm.tokenizer.pad_token_id)

hedda_stage = GenerativeStage(SCRIPT_PATH, default_llm=llama_path)
PLAYER_NAME = "Edward Helson"
player = Player(PLAYER_NAME)
hedda_stage.add_player(player)

def prompt_player_input() -> bool:
    print(player.name, "is in the Act: ", player.current_act)
    act_dict = {}
    for act_name in hedda_stage.current_act_names:
        act_dict[len(act_dict) + 1] = act_name
    candidate_str = "; ".join([f"[{k}] {v}" for k, v in act_dict.items()] + ["[0] Do nothing; \ninput [-1] for interview."])
    print("Input the numbers below to enter the act, or directly input the text to begin a conversation: " + candidate_str)
    user_input = input()
    try:
        number_input = int(user_input)
        if number_input == 0:
            player.action = {"action": "none", "content": ""}
            return True
        elif number_input == -1:
            prompt_guide_interview()
            return False
        elif number_input in act_dict:
            player.action = {"action": "move", "content": act_dict[number_input]}
            return True
        else:
            raise ValueError
    except ValueError:
        string_input = str(user_input)
        player.action = {"action": "talk", "content": string_input}
        return True

def prompt_guide_interview():
    def prompt_interview(actor: GenerativeActor):
        while True:
            print("Input the question you are interested in, or input [0] to exit the interview: ")
            user_input = input()
            if user_input == "0":
                actor.interview_history.clear()
                return
            else:
                response = actor.interview(user_input)
                print(f"{actor.name}：{response}")

    actor_dict = {}
    for actor_name in hedda_stage.actors:
        actor_dict[len(actor_dict) + 1] = actor_name
    candidate_str = "; ".join([f"[{k}] {v}" for k, v in actor_dict.items()] + ["[0] Exit"])
    while True:
        print("Input the numbers below to select an actor you want to interview: " + candidate_str)
        user_input = input()
        try:
            number_input = int(user_input)
            if number_input == 0:
                return
            elif number_input in actor_dict:
                actor_name = actor_dict[number_input]
                actor = hedda_stage.actors[actor_name]
                actor.interview_history = copy.deepcopy(actor.dialogue_history.active_history)
                actor.interview_history.append({"role": "Narration", "content": f"(Director has paused the play. Now please continue to answer the questions of user as the role of {actor.name}.)"})
                prompt_interview(actor)
            else:
                raise ValueError
        except ValueError:
            pass


print("********************", hedda_stage.script.title, "********************")
print("Drama Background")
print(hedda_stage.script.intro)
input("Press Any Key to Continue...")
hedda_stage.load_next_act()

finished = False
while not finished:
    has_input = False
    while not has_input:
        has_input = prompt_player_input()
    finished = hedda_stage.step()
prompt_guide_interview()
